# simple_ssvep
Really simple PsychoPy code to generate SSVEP stimuli and send markers.
